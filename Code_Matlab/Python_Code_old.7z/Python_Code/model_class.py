
import numpy as np
from utils import rpy2dc

# Helper functions

def build_c0_S0(links):
    """Build matrices c0 and SO"""
    numJ = len(links) - 1
    c0 = np.zeros((3,numJ))
    S0 = np.zeros(numJ)
    for k, v in links[0].c0.items():
        c0[:,k-1] = np.asarray(v)
        S0[k-1] = 1
    return c0, S0

def build_cc_SS(links):
    """Build matrices cc and SS"""
    numJ = len(links) - 1
    cc = np.zeros((3,numJ,numJ))
    SS = np.zeros((numJ,numJ))
    for i in range(numJ):
        for k, v in links[i+1].cc.items():
            cc[:,i,k-1] = np.asarray(v)
            SS[i,k-1] = 1
        SS[i,i] = -1
    return cc, SS

def build_ce_SE(links):
    """Build matrices ce and SE"""
    numJ = len(links) - 1
    ce = np.zeros((3,numJ))
    SE = np.zeros(numJ)
    for i in range(numJ):
        for k, v in links[i+1].ce.items():
            ce[:,k-1] = np.asarray(v)
            SE[k-1] = 1
    return ce, SE

def build_BB(SS):
    """Build vector BB"""
    numJ = SS.shape[1]
    BB = np.zeros(numJ)
    for col in range(numJ):
        for row in range(col):
            if (np.absolute(SS[row,col]) == 1):
                BB[col] = row + 1
                break
    return BB

def build_mass_inertia(links):
    """Build the system vector mass and matrix inertia"""
    numL = len(links)
    mass = np.zeros(numL)
    inertia = np.zeros((3,3*numL))
    for i in range(numL):
        mass[i] = links[i].mass
        inertia[:,3*i:3*(i+1)] = links[i].inertia
    return mass, inertia

def build_Qi_Qe(links):
    """Build Qi and Qe for all joints/links"""
    numJ = len(links) - 1
    Qi = np.zeros((3,numJ))
    Qe = np.zeros((3,numJ))
    for i in range(numJ):
        Qi[:,i] = links[i+1].Qi
        Qe[:,i] = links[i+1].Qe
    return Qi, Qe

# Class model

class model:

    # Default values
    Gravity = np.array([-9.81,0.0,0.0])
    Ez = np.array([0.0, 0.0, 1.0])
    zeroV = np.zeros(3)     # Zero vector of 3 elements

    def __init__(self, links, joints, Gravity=Gravity, Ez=Ez):
        """Build model connectivity and initialize properties"""
        self.numJ = len(joints)     # Number of joints
        self.numL = len(links)      # Number of links (number of joints + 1)
        self.links = links
        self.joints = joints
        self.Gravity = np.asarray(Gravity)      # Gravity
        self.Ez = np.asarray(Ez)                # Local joint z-axis
        self.mass, self.inertia = build_mass_inertia(links)     # Masses and inertias
        self.Qi, self.Qe = build_Qi_Qe(links)
        self.c0, self.S0 = build_c0_S0(links)
        self.cc, self.SS = build_cc_SS(links)
        self.ce, self.SE = build_ce_SE(links)
        self.BB = build_BB(self.SS)
   

    def set_init(self, R0=zeroV, Q0=zeroV, V0=zeroV, W0=zeroV, q0=None, qd0=None):
        """Initialize quantities at starting time"""
        # Centroids relative orientations Qi and absolute rotation matrices AA
        self.Qi = np.zeros((3,self.numL))
        self.AA = np.zeros((3,3*self.numL))
        self.Qi[:,0] = Q0


        # self.RR[:,0] = R0
        # self.vv[:,0] = V0
        # self.ww[:,0] = W0
        # if (q0 != None):
        #     self.q = q0 
        # if (qd0 != None):
        #     self.qd = qd0 

        # self.RR = np.zeros((3,self.numL))       # Position centroids
        # self.vv = np.zeros((3,self.numL))       # Linear velocity centroids
        # self.ww = np.zeros((3,self.numL))       # Angular velocity centroids
        # self.vd = np.zeros((3,self.numL))       # Linear acceleration centroids
        # self.wd = np.zeros((3,self.numL))       # Angular acceleration centroids
        # self.q = np.zeros(self.numJ)            # Joint values
        # self.qd = np.zeros(self.numJ)           # Joint velocities
        # self.qdd = np.zeros(self.numJ)          # Joint acceleration
        # self.AA = build_AA(self.Qi)             # Rotation matrices

