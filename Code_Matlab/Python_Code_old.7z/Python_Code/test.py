
import numpy as np
import joint_class as jc
import link_class as lc
import model_class as mc
from utils import *

# Add links (geometrical and physical properties)
shape = ('Cylinder', 0.020, 0.0, 0.5)
In = inertia_matrix(shape)
L0 = lc.link(2.3, In, c0={1: [0.05, 0.0, 0.0]}, name='base/foot')
# Leg
a1 = {1: [-0.2, 0.0, 0.0],
      2: [ 0.2, 0.0, 0.0],
      4: [ 0.2, 0.0, 0.0]}
L1 = lc.link(0.4, In, cc=a1, name='leg')
# Trunk
a2 = {2: [-0.2, 0.0, 0.0],
      3: [ 0.2, 0.0, 0.0]}
L2 = lc.link(0.4, In, cc=a2, name='trunk')
# Upper arm
a3 = {3: [-0.2, 0.0, 0.0]}
L3 = lc.link(0.4, In, cc=a3, ce={3: [0.2, 0.0, 0.0]}, name='upper_arm')
# Lower arm
a4 = {4: [-0.2, 0.0, 0.0]}
L4 = lc.link(0.4, In, cc=a4, ce={4: [0.3, 0.0, 0.0]}, name='lower_arm')
# Third arm
a5 = {5: [-0.2, 0.0, 0.0]}
L5 = lc.link(0.4, In, cc=a5, ce={5: [0.3, 0.0, 0.0]}, name='third_arm')
# Put together
# links = [L0, L1, L2, L3, L4, L5]
links = [L0, L1, L2, L3, L4, L5]

# Add joints (geometrical properties)
J1 = jc.joint('R', name='joint_foot_leg')
J2 = jc.joint('R', name='joint_leg_trunk')
J3 = jc.joint('R', name='joint_trunk_upper_arm')
J4 = jc.joint('R', name='joint_leg_lower_arm')
J5 = jc.joint('R', name='joint_foot_third_arm')
joints = [J1, J2, J3, J4, J5]

# Build model
# Gravity = [-9.81, 0.0, 0.0]         # Axis x is the vertical one
# Ez = [0.0, 0.0, 1.0]
robot = mc.model(links, joints)

print(robot.Ez)