
import sys
import numpy as np

def check_Jtype(Jtype):
    n = len(Jtype)
    for i in range(n):
        if (Jtype[i] != 'R' and Jtype[i] != 'P'):
            print("\nJoint type {0} not recognized\n".format(Jtype[i]))
            sys.exit(1)
    return Jtype

class link:

    # Default values
    zeroV = np.zeros(3)         # Zero vector of 3 elements
    idenM = np.identity(3)      # 3 x 3 identity matrix

    def __init__(self, mass=0, inertia=idenM, c0={}, cc={}, ce={}, Qi=zeroV, Qe=zeroV, name=None):
        self.mass = mass            # Mass [kg]
        self.inertia = inertia      # Moments of inertia [kgm^2]
        self.c0 = c0
        self.cc = cc
        self.ce = ce
        self.Qi = Qi                # Centroid (relative) orientation
        self.Qe = Qe                # End-point (relative) orientation
        self.name = name

        # self.RR = np.zeros(3)       # Centroid position
        # self.vv = np.zeros(3)       # Centroid linear velocity
        # self.ww = np.zeros(3)       # Centroid angular velocity
        # self.vd = np.zeros(3)       # Centroid linear acceleration
        # self.wd = np.zeros(3)       # Centroid angular acceleration

