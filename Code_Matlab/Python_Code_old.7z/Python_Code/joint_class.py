
import sys
import numpy as np

# Helper functions

def check_Jtype(Jtype):
    n = len(Jtype)
    for i in range(n):
        if (Jtype[i] != 'R' and Jtype[i] != 'P'):
            print("\nJoint type {0} not recognized\n".format(Jtype[i]))
            sys.exit(1)
    return Jtype

# Class joint

class joint:

    def __init__(self, Jtype='R', name=None):
        self.Jtype = check_Jtype(Jtype)
        self.name = name
        # self.q = 0.0
        # self.qd = 0.0
        # self.qdd = 0.0

