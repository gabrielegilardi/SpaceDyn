
from math import pi
from utils import *

print('\nTest rotX rotY rotX')
theta = 30.0*pi/180.0
print('theta=',theta)
print('rotX=',rotX(theta))
print('rotY=',rotY(theta))
print('rotZ=',rotZ(theta))

print('\nTest tilde')
a = np.array([1.3, -2.3, 0.7])
print('a=',a)
print('tilde=',tilde(a))

print('\nTest rpy2dc')
rpy = np.array([1.3, -2.3, 0.7])
roll = 1.3
pitch = -2.3
yaw = 0.7
print('C=',rpy2dc(rpy))
print('C=',rpy2dc(roll,pitch,yaw))

print('\nTest eul2dc')
eul = np.array([1.3, -2.3, 0.7])
phi = 1.3
theta = -2.3
psi = 0.7
print('C=',eul2dc(eul))
print('C=',eul2dc(phi,theta,psi))

print('\nTest cross')
u = np.array([1.3, -2.3,  0.7])
v = np.array([0.5,  1.2, -3.2])
print('n=',cross(u,v))

print('\nTest dc2rpy')
C = rpy2dc([1.3, -2.3, 0.7])
print(dc2rpy(C))

print('\nTest dc2eul')
C = eul2dc([1.3, -2.3, 0.7])
print(dc2eul(C))

print('\nTest tr2diff')
AA1 = eul2dc([1.3, -2.3, 0.7])
AA2 = eul2dc([2.1,  0.5, 4.7])
print(tr2diff(AA1,AA2))

print('\nTest rotW')
w0 = np.array([1.3, -2.3,  0.7])
dtime = 2.0
print(rotW(w0, dtime))
